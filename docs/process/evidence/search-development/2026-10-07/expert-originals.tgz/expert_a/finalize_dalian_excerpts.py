# -*- coding: utf-8 -*-
import json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;r=R/'dalian';p=r/'findings.unreviewed.json';x=json.loads(p.read_text())
N={'programme':('Introduction to Undergraduate Training Programs',550),'english':('English-Taught Program, requirement',950),'school':('1. Non-Chinese Citizen',1250),'chinese':('Chinese-Taught Program',650),'deadline':('Applications will be accepted',300),'cost_en':('Fees (CNY)',1400),'cost_zh':('Fees (CNY)',700),'scholarship':('Article 7',1000),'eligible':('Article 10 Allocation',900),'scholarship_2026':('Bachelor degree Scholarship (only for new students)',560),'catalogue':('2026 Bachelor Programs (English-taught)',500)}
for key,e in x['evidence'].items():
 if key.startswith('pdf_'):
  e['verbatim_excerpt']='';e['verbatim_excerpt_normalization']='No readable content; production Fetcher outcome refused_privacy.';continue
 v=json.loads((r/f"view-{e['action']:03}.json").read_text());t=v.get('text','');needle,length=N[key];i=t.find(needle)
 if i<0:
  t=' '.join(t.split());needle=' '.join(needle.split());i=t.find(needle);normal='Whitespace collapsed; words unchanged.'
 else:normal='Exact controller-readable text substring.'
 if i<0:raise ValueError(key)
 e['verbatim_excerpt']=t[i:i+length];e['verbatim_excerpt_normalization']=normal;e['verbatim_excerpt_sha256']=hashlib.sha256(e['verbatim_excerpt'].encode()).hexdigest()
 e['excerpt_processing']='Existing excerpt normalizes line/table layout; verbatim_excerpt supplies direct retained text.'
x['local_finalization_note']='Dalian draft writer hit local Python3.9 errors; saved successfully with existing backend venv at16:15:51UTC. Nagoya first query began16:15:28UTC while Dalian final save was being repaired. No Dalian network action began after original wall guard; no timer reset/replay.'
p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
m=R/'completion.unreviewed.json';meta=json.loads(m.read_text());meta['chronology_note']=x['local_finalization_note']
meta['cases'][0]['findings_sha256']=hashlib.sha256(p.read_bytes()).hexdigest();m.write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print({'dalian_findings_sha256':meta['cases'][0]['findings_sha256'],'verbatim_excerpts_added':len(N)})
