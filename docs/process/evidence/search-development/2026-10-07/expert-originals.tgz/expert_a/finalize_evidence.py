# -*- coding: utf-8 -*-
import json, hashlib, re
from pathlib import Path
from datetime import UTC,datetime
R=Path(__file__).resolve().parent
selectors={
'g30_2027':(2,'Availability of Programs',1700,None),
'g30_faq':(3,'I am interested in Computer Science',350,None),
'cs_department':(5,'Department of Computer Science',450,None),
'april_route':(8,'April admission',620,None),
'cs_2027_japanese_list':(11,'Ⅰ 募 集 人 員',750,None),
'degree_general':(17,'コ ン ピ ュ ー タ 科 学 科',200,None),
'campus_general':(15,'Most Labratories',420,None),
'g30_english_2027':(2,'Appendix 1',1500,30),
'japanese_cs_language_tests':(11,'情報学部 \n（コンピュータ科学科）',1400,None),
'japanese_cs_school_qualification':(11,'1． 出 願 資 格',1050,None),
'g30_school_qualification':(2,'I. Eligibility for Application',2400,None),
'g30_deadlines':(2,'Admission Round Starts Deadline',520,None),
'japanese_deadlines':(9,'■2027年度入試日程',1000,None),
'tuition_g30_2027':(2,'2. Other Fees Required After Enrollment',1100,28),
'tuition_japanese_2027':(11,'⑶ 入学料等学生納入金',1450,None),
'living_estimate_general':(12,'Monthly living expenses',1000,None),
'g30_scholarships_general':(10,'G30 Undergraduate Scholarship \n\nScholarship',1600,None),
'international_scholarship_general':(10,'<Non-Japanese Nationals>',430,None),
'mext_designated_countries_old':(18,'As of September 2023',1700,None),
'outdated_scholarship_page':(13,'Scholarship Provision (2019)',650,None),
}
for case in ['dalian','nagoya']:
 root=R/case; p=root/'findings.unreviewed.json';x=json.loads(p.read_text()); summary=json.loads((root/'summary.json').read_text());fail=[]
 for name,expected in summary['raw_logs'].items():
  actual=hashlib.sha256((root/'raw'/name).read_bytes()).hexdigest()
  if actual!=expected:fail.append(name)
 for key,e in x['evidence'].items():
  actual=hashlib.sha256(Path(e['raw_path']).read_bytes()).hexdigest()
  if actual!=e['raw_sha256']:fail.append(key)
  if case=='nagoya':
   n,needle,length,page=selectors[key]
   v=json.loads((root/(f'view-002-page-{page:02}.json' if page else f'view-{n:03}.json')).read_text())
   text=(root/'text-011.txt').read_text() if n==11 else v.get('text','')
   i=text.find(needle)
   if i<0:
    normalized=' '.join(text.split()); ns=' '.join(needle.split());i=normalized.find(ns)
    if i<0:fail.append('needle:'+key);continue
    e['verbatim_excerpt']=normalized[i:i+length];e['verbatim_excerpt_normalization']='Whitespace collapsed; words unchanged.'
   else:e['verbatim_excerpt']=text[i:i+length];e['verbatim_excerpt_normalization']='Exact controller-readable text substring.'
   e['excerpts_processing']='Existing excerpts normalize line/table layout; verbatim_excerpt supplies direct retained text.'
   e['verbatim_excerpt_sha256']=hashlib.sha256(e['verbatim_excerpt'].encode()).hexdigest()
 x['evidence_validation']={'at':datetime.now(UTC).isoformat(),'raw_hashes_verified':len(summary['raw_logs']),'failures':fail,'schema_review':'unreviewed','semantic_review':'unreviewed'}
 p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
 print(case,'validation',x['evidence_validation'])
meta={'review_status':'unreviewed','completed_artifacts_for_attempted_cases':2,'real_attempted_cases':2,'unrun_cases':0,'cases':[],'network_actions_finished':True,'no_further_network_after_final_files':True,'finished_at':datetime.now(UTC).isoformat()}
for case in ['dalian','nagoya']:
 root=R/case;x=json.loads((root/'findings.unreviewed.json').read_text())
 meta['cases'].append({'case':case,'case_id':x['case_id'],'final_state':x['final_state'],'wall_start':x['wall_start'],'finished_at':x['finished_at'],'budget':x['budget'],'findings':str(root/'findings.unreviewed.json'),'report':str(root/'report.ru.md'),'findings_sha256':hashlib.sha256((root/'findings.unreviewed.json').read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((root/'report.ru.md').read_bytes()).hexdigest()})
(R/'completion.unreviewed.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));print('completion',meta)
