import argparse
import asyncio
import hashlib
import json
import sys
from datetime import UTC, datetime
from pathlib import Path

from evaluation.research.expert.controller import expert_view, run

ROOT = Path(__file__).resolve().parent
STOP = ROOT.parents[1] / 'development-STOP.json'
CASES = {
    'dalian': ('01d3bb22815c61aa8454283116cbd4fa', 'dlut.edu.cn'),
    'nagoya': ('01ea8dd78746c15f2655b59fd4f5deab', 'nagoya-u.ac.jp'),
}

def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')

def stop(case, action, status, reason):
    evidence = dict(case=case, action=action, http_status=status,
                    failure_reason=reason, time=datetime.now(UTC).isoformat())
    try:
        with STOP.open('x', encoding='utf-8') as out:
            json.dump(evidence, out, ensure_ascii=False, indent=2)
    except FileExistsError:
        pass
    return evidence

parser = argparse.ArgumentParser()
parser.add_argument('case', choices=CASES)
parser.add_argument('tool', choices=('fetcher', 'search_provider'))
parser.add_argument('target')
args = parser.parse_args()
case_id, domain = CASES[args.case]
case_root = ROOT / args.case
case_root.mkdir(parents=True, exist_ok=True)
now = datetime.now(UTC)
wall_path = case_root / 'wall_start.json'
if not wall_path.exists():
    save(wall_path, {'time': now.isoformat()})
wall_start = datetime.fromisoformat(json.loads(wall_path.read_text())['time'])
wall_ms = int((now - wall_start).total_seconds() * 1000)
if STOP.exists():
    print(json.dumps({'state': 'global_stop', 'case': args.case}))
    sys.exit(3)
if wall_ms >= 900000:
    print(json.dumps({'state': 'wall_guard', 'case': args.case, 'wall_ms': wall_ms}))
    sys.exit(4)
summary_path = case_root / 'summary.json'
previous = json.loads(summary_path.read_text()) if summary_path.exists() else None
number = previous['final']['next_log_number'] if previous else 1
action = {'tool': args.tool}
if args.tool == 'fetcher':
    action['url'] = args.target
else:
    action.update(query=args.target, domains=[domain], max_results=8)
plan = dict(case_id=case_id, provider='exa', log_prefix=args.case,
            strict_budget=True, max_calls=60, max_search_queries=6, max_ms=120000,
            official_domains=[domain], budget_origin='independent_full_budget',
            actions=[action])
if previous:
    plan['resume_summary'] = previous
plan_path = case_root / f'plan-{number:03d}.json'
save(plan_path, plan)
# The final check is immediately before controller.run can perform any I/O.
if STOP.exists():
    print(json.dumps({'state': 'global_stop', 'case': args.case}))
    sys.exit(3)
try:
    summary = asyncio.run(run(plan_path, case_root / 'raw', case_root / 'cache'))
except Exception as exc:
    error = {'case': args.case, 'action': number, 'exception_type': type(exc).__name__,
             'reason': 'controller_setup_or_execution_exception', 'time': now.isoformat()}
    save(case_root / f'setup-error-{number:03d}.json', error)
    if args.tool == 'search_provider':
        error['stop'] = stop(args.case, number, None, error['reason'])
    print(json.dumps(error))
    sys.exit(5)
save(case_root / f'summary-{number:03d}.json', summary)
save(summary_path, summary)
last = summary['actions'][-1]
raw_path = case_root / 'raw' / last['raw_log_path']
raw = json.loads(raw_path.read_text())
response = raw.get('response') or {}
provider_failure = args.tool == 'search_provider' and (
    response.get('outcome_status') != 'success' or not raw.get('executed')
)
view = expert_view(raw, chars=30000, links=160, sections=100)
save(case_root / f'view-{number:03d}.json', view)
result = {'case': args.case, 'action': number, 'final': summary['final'],
          'raw_file': str(raw_path), 'raw_sha256': last['raw_log_sha256'], 'view': view}
if provider_failure:
    reason = response.get('failure_reason') or response.get('outcome') or raw.get('outcome') or 'provider_failure'
    result['GLOBAL_STOP'] = stop(args.case, number, response.get('http_status'), reason)
print(json.dumps(result, ensure_ascii=False))
