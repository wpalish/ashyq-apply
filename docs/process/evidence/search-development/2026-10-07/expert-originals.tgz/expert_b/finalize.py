import base64
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/Users/wpalish/Documents/Codex/2026-10-07/x20/work/development-experts/expert_b')


def h(value):
    return hashlib.sha256(value).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def main():
    combined = []
    validation = []
    for case in ('wits', 'aut', 'caltech'):
        folder = ROOT / case
        findings = json.loads((folder / 'findings-draft.json').read_text())
        state = json.loads((folder / 'state.json').read_text())
        summary = state['summary']
        sources = {}
        texts = {}
        searches = []
        seen = set()
        counters = (0, 0, 0)
        raw_paths = sorted((folder / 'raw').glob(f'{case}-*.json'))
        for path in raw_paths:
            data = path.read_bytes()
            sha = h(data)
            assert sha == summary['raw_logs'][path.name]
            raw = json.loads(data)
            assert raw['case_id'] == findings['case_id']
            assert raw['policy_mode'] == 'same_policy'
            assert raw['executed']
            assert raw['tool_policy']['strict_budget']
            assert raw['tool_policy']['budget_origin'] == 'independent_full_budget'
            request = raw['request']
            canonical = json.dumps(request, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
            action_hash = h(canonical)
            assert action_hash not in seen, 'Repeated exact request'
            seen.add(action_hash)
            next_counters = (raw['fetcher_calls_cumulative'], raw['elapsed_ms_cumulative'], raw['search_queries_cumulative'])
            assert all(new >= old for new, old in zip(next_counters, counters))
            counters = next_counters
            response = raw['response']
            number = int(path.stem.rsplit('-', 1)[1])
            view = json.loads((folder / f'view-{number:03d}.json').read_text())
            source = {
                'action': number, 'action_hash_sha256': action_hash,
                'raw_log_path': str(path), 'raw_log_sha256': sha,
                'tool': request['tool'], 'request': request,
                'outcome': response.get('outcome'), 'outcome_status': response.get('outcome_status'),
                'http_status': response.get('status_code', response.get('http_status')),
                'scope': 'official Fetcher content' if response.get('ok') else 'discovery hint only' if request['tool'] == 'search_provider' else 'access failure; no facts read',
            }
            if request['tool'] == 'search_provider':
                source['results'] = response['results']
                searches.append(source)
            else:
                source.update(official_url=response.get('final_url') or request['url'],
                              fetched_at=response.get('fetched_at'), content_sha256=response.get('content_sha256'),
                              text_sha256=view.get('text_sha256'), text_total_chars=view.get('text_total_chars', 0))
                body = base64.b64decode(response.get('content_b64') or '')
                assert h(body) == response['content_sha256']
                if response.get('ok'):
                    assert view.get('text_next_offset') is None
                    texts[number] = view.get('text', '')
                sources[number] = source
        assert len(findings['questions']) == 7
        for question in findings['questions']:
            for evidence in question.get('evidence', []):
                action = evidence['action']
                assert evidence['excerpt'] in texts[action], f'{case} {question["id"]} action{action}: excerpt mismatch'
                evidence.update(sources[action])
                evidence['excerpt_text_start'] = texts[action].index(evidence['excerpt'])
                evidence['scope'] = question.get('scope', 'Claim limited by answer and unknown_reasons; source year is not widened.')
            if 'access_evidence' in question:
                question['access_evidence'] = [sources[number] for number in question['access_evidence']]
        budget = summary['final']
        assert budget['fetcher_calls'] <= 60 and budget['search_queries'] <= 6
        assert state['active_ms_including_setup'] <= 120000
        assert counters == (budget['fetcher_calls'], budget['elapsed_ms'], budget['search_queries'])
        findings.update(
            saved_at=datetime.now(UTC).isoformat(), expert='expert_b',
            method='Independent collaborative expert. Existing controller.run and production Fetcher only; Exa is discovery only. No gold, algorithm outputs, or other expert evidence read. No source/git/docs edits.',
            budget={**budget, 'active_ms_including_setup': state['active_ms_including_setup'],
                    'max_fetcher_calls': 60, 'max_search_queries': 6, 'max_active_ms': 120000,
                    'first_action_at': state['first_action_at'], 'model_thinking_between_actions': 'excluded',
                    'algorithm_comparison_caveat': 'Algorithm120s includes setup; controller timing is separately reported. Expert active_ms_including_setup measures controller.run including its setup, excluding separate process import/model thinking.'},
            source_catalog=list(sources.values()), discovery_only_searches=searches,
            validation={'raw_hashes_verified': True, 'content_hashes_verified': True,
                        'excerpts_exactly_matched': True, 'cumulative_counters_monotone': True,
                        'no_repeated_exact_actions': True, 'source_facts_human_review': 'unreviewed'})
        save(folder / 'findings.json', findings)
        report = [f'# {findings["university"]}: независимые экспертные находки',
                  'Статус: **не проверено другим экспертом**. Запрос: гражданин Казахстана, Bachelor, Computer Science, 2027 / 2027–28.',
                  findings['intake_interpretation'],
                  f'Расход: Fetcher {budget["fetcher_calls"]}/60; Exa {budget["search_queries"]}/6; controller {budget["elapsed_ms"]} ms; active including controller setup {state["active_ms_including_setup"]}/120000 ms. Между действиями мышление модели исключено. Импорт отдельного процесса не входит в эту метрику. Алгоритмический бюджет 120 s включает setup и не объявлен напрямую идентичным.',
                  'Сетевые действия: только существующий экспертный контроллер и production Fetcher. Search snippets сохранены как discovery hints. Документы другого года или категории заявителя не подтверждают целевой год/категорию.']
        for question in findings['questions']:
            report.extend([f'## {question["id"]} — {question["status"]}', question['answer_ru']])
            if question.get('scope'):
                report.append('Область действия: ' + question['scope'])
            if question.get('unknown_reasons'):
                report.append('Неизвестное: ' + ' '.join(question['unknown_reasons']))
            if question.get('source_conflicts'):
                report.append('Конфликт источника: ' + ' '.join(question['source_conflicts']))
            for evidence in question.get('evidence', []):
                excerpt = evidence['excerpt'].replace('\n', ' ')
                report.append(f'- [{evidence["official_url"]}]({evidence["official_url"]}) — action {evidence["action"]}; raw `{evidence["raw_log_path"]}`; raw SHA256 `{evidence["raw_log_sha256"]}`; action SHA256 `{evidence["action_hash_sha256"]}`. Точная выдержка: «{excerpt}».')
            for evidence in question.get('access_evidence', []):
                report.append(f'- [{evidence["official_url"]}]({evidence["official_url"]}) — HTTP {evidence["http_status"]}, содержимое не прочитано; action {evidence["action"]}; raw `{evidence["raw_log_path"]}`; raw SHA256 `{evidence["raw_log_sha256"]}`; action SHA256 `{evidence["action_hash_sha256"]}`.')
        report.append('Проверка сохранённых артефактов: raw/content SHA256 совпадают, цитаты точно совпадают с распарсенным текстом, накопительные счётчики не уменьшаются, повторных точных действий нет. Это техническая проверка, а не второй содержательный обзор.')
        (folder / 'report.ru.md').write_text('\n\n'.join(report) + '\n', encoding='utf-8')
        combined.append({'university': findings['university'], 'case_id': findings['case_id'],
                         'findings': str(folder / 'findings.json'), 'report_ru': str(folder / 'report.ru.md'),
                         'budget': findings['budget'], 'review_status': 'unreviewed',
                         'status_by_question': {q['id']: q['status'] for q in findings['questions']}})
        validation.append({'case': case, 'passed': True, 'raw_actions': len(raw_paths), 'excerpt_count': sum(len(q.get('evidence', [])) for q in findings['questions'])})
    save(ROOT / 'manifest.json', {'expert': 'expert_b', 'cases': combined, 'unrun_assigned_cases': [], 'validation': validation})
    print(json.dumps({'cases': combined, 'validation': validation}, ensure_ascii=False))


if __name__ == '__main__':
    main()
