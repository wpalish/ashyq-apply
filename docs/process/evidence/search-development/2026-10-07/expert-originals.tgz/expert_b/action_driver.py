import asyncio
import json
import os
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

from evaluation.research.expert.controller import expert_view, run

ROOT = Path('/Users/wpalish/Documents/Codex/2026-10-07/x20/work/development-experts/expert_b')
STOP = ROOT.parents[1] / 'development-STOP.json'
CASES = {
    'wits': ('0386940c5cef525b3c8e7966868f5ed6', 'wits.ac.za'),
    'aut': ('0480c3b293c219debd4325fe107ac27b', 'aut.ac.nz'),
    'caltech': ('05e4d59f87261553f15d14b0cdb470d2', 'caltech.edu'),
}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def global_stop(case, action, reason, status=None):
    value = {'case': case, 'action': action, 'http_status': status,
             'reason': reason, 'at': datetime.now(UTC).isoformat(), 'expert': 'expert_b'}
    temporary = ROOT / f'.stop-{os.getpid()}.json'
    save(temporary, value)
    try:
        os.link(temporary, STOP)
    except FileExistsError:
        pass
    finally:
        temporary.unlink(missing_ok=True)
    print(json.dumps({'GLOBAL_STOP': value}, ensure_ascii=False))


def main():
    case, action_json = sys.argv[1:3]
    if STOP.exists():
        print('STOP_PRESENT: no action executed')
        return
    case_id, domain = CASES[case]
    directory = ROOT / case
    directory.mkdir(exist_ok=True)
    state_path = directory / 'state.json'
    state = json.loads(state_path.read_text()) if state_path.exists() else {}
    now = time.time()
    first_action_at = state.get('first_action_epoch', now)
    if now - first_action_at >= 900:
        print('WALLCLOCK_STALL_GUARD: no action executed')
        return
    action = json.loads(action_json)
    old_summary = state.get('summary')
    plan = {'case_id': case_id, 'provider': 'exa', 'strict_budget': True,
            'max_calls': 60, 'max_search_queries': 6, 'max_ms': 120000,
            'official_domains': [domain], 'budget_origin': 'independent_full_budget',
            'log_prefix': case, 'actions': [action]}
    if old_summary:
        plan.update(resume_summary=old_summary,
                    start_calls=old_summary['final']['fetcher_calls'],
                    start_search_queries=old_summary['final']['search_queries'],
                    start_ms=max(old_summary['final']['elapsed_ms'], state['active_ms_including_setup']))
    number = old_summary['final']['next_log_number'] if old_summary else 1
    plan_path = directory / f'plan-{number:03d}.json'
    save(plan_path, plan)
    if STOP.exists():
        print('STOP_PRESENT: no action executed')
        return
    began = time.monotonic()
    try:
        summary = asyncio.run(run(plan_path, directory / 'raw', directory / 'cache'))
    except Exception as exc:
        save(directory / f'run-error-{number:03d}.json', {'exception_class': type(exc).__name__,
             'at': datetime.now(UTC).isoformat(), 'action': action, 'detail': 'withheld to avoid secrets'})
        global_stop(case, action, 'controller_run_exception_' + type(exc).__name__)
        return
    elapsed_run_ms = int((time.monotonic() - began) * 1000 + 0.999)
    active_ms = max(summary['final']['elapsed_ms'], state.get('active_ms_including_setup', 0) + elapsed_run_ms)
    save(directory / f'summary-{number:03d}.json', summary)
    state = {'first_action_epoch': first_action_at, 'first_action_at': datetime.fromtimestamp(first_action_at, UTC).isoformat(),
             'summary': summary, 'active_ms_including_setup': active_ms,
             'last_run_ms_including_setup': elapsed_run_ms}
    save(state_path, state)
    entry = summary['actions'][0]
    raw_path = directory / 'raw' / entry['raw_log_path']
    record = json.loads(raw_path.read_text())
    response = record.get('response') or {}
    is_failure = action['tool'] == 'search_provider' and response.get('outcome_status') == 'failure'
    auth_quota = response.get('http_status', response.get('status_code')) in {401, 402, 429}
    if is_failure or auth_quota:
        global_stop(case, action, response.get('failure_reason') or response.get('outcome') or 'provider_failure',
                    response.get('http_status', response.get('status_code')))
    view = expert_view(record, chars=30000, links=200, sections=0)
    save(directory / f'view-{number:03d}.json', view)
    display_view = {k: v for k, v in view.items() if k not in {'links', 'sections'}}
    display_view['discovery_links'] = [link for link in view.get('links', [])
        if any(term in (link['url'].split('.edu', 1)[-1] + ' ' + link['text']).lower() for term in
               ('admiss', 'english', 'international', 'matric', 'fee', 'scholar', 'bursar',
                '2027', 'calendar', 'term-dat', 'computer', 'science', 'prospect', 'financial'))]
    print(json.dumps({'case': case, 'action': number, 'controller_final': summary['final'],
                      'active_ms_including_setup': active_ms, 'raw_log_path': str(raw_path),
                      'raw_log_sha256': entry['raw_log_sha256'], 'view': display_view}, ensure_ascii=False))


if __name__ == '__main__':
    main()
