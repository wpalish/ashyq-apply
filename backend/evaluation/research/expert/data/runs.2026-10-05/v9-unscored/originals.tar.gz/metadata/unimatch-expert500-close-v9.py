"""Close an original failed V9 attempt without labels or new external calls."""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import io
import json
import runpy
import tarfile
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

REPO = Path('/Users/wpalish/Documents/Codex/2026-09-28/files-mentioned-by-the-user-2026/work/ashyq-apply')
ROOT = REPO / 'artifacts/expert-500/phase1-v9-2026-10-05'
DEST = REPO / 'backend/evaluation/research/expert/data/runs.2026-10-05/v9-unscored'

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path: Path):
    return json.loads(path.read_text())

assert not DEST.exists(), 'Never overwrite a closed attempt'
assert not (ROOT / 'submission-seal.json').exists()
assert not (ROOT / 'comparison.json').exists()
trial = read(ROOT / 'trial.json')
assert digest(ROOT / 'trial.json') == digest(ROOT / 'trial-at-baseline-start.json')
for filename, expected in trial['scripts'].items():
    assert digest(Path(filename)) == expected, filename
for name, expected in trial['modules'].items():
    spec = importlib.util.find_spec(name)
    assert spec is not None and spec.origin is not None
    assert digest(Path(spec.origin)) == expected, name
protocol = REPO / 'backend/evaluation/research/expert/data/protocol.2026-10-05/v9'
assert digest(protocol / 'manifest.json') == trial['expert_protocol']['manifest_file_sha256']
checkpoint = REPO / 'backend/evaluation/research/expert/data/runs.2026-10-05/v9-baseline-checkpoint/manifest.json'
for record in read(checkpoint)['records']:
    assert digest(checkpoint.parent / record['path']) == record['sha256']
    assert digest(Path(record['original_path'])) == record['sha256']

report = runpy.run_path('/tmp/unimatch-expert500-journal-report-v9.py')
pilot = runpy.run_path('/tmp/unimatch-expert500-journal-pilot-v9.py')
results = read(ROOT / 'experts-results.json')
cases = []
for result in results['results']:
    case = result['case_id']
    folder = ROOT / 'experts' / case
    metas = sorted(folder.glob('selector-*.meta.json'), key=lambda p: int(p.name.split('-')[1].split('.')[0]))
    terminal_meta = metas[-1]
    terminal_stream = terminal_meta.with_name(terminal_meta.name.replace('.meta.json', '.events.jsonl'))
    events = [json.loads(line) for line in terminal_stream.read_text().splitlines() if line.strip()]
    failures = [event for event in events if event['type'] == 'turn.failed']
    assert len(failures) == 1 and 'hit your usage limit' in failures[0]['error']['message']
    assert read(terminal_meta)['returncode'] != 0
    record = {
        'case_id': case, 'status': result['status'], 'terminal_error': result['error'],
        'model_calls': len(metas), 'accepted_turns': result.get('accepted_turns', 0),
        'recorded_source_actions': result['actions'], 'active_ms': result['active_ms'],
        'terminal_selector': terminal_meta.name,
        'terminal_stream_sha256': digest(terminal_stream),
        'model_refusal': failures[0]['error']['message'],
        'model_refusal_finished_at': read(terminal_meta)['model_ended_at'],
        'rejected_checkpoints': dict(Counter(e['feedback']['error'] for e in result.get('turn_errors', []) if e['kind'] == 'rejected_checkpoint')),
        'whole_cohort_eligible': False,
    }
    if result.get('validated'):
        packet = read(ROOT / 'baseline' / case / 'public-packet.json')
        trace = read(folder / 'trace.json')
        source = report['verify_source_ledger'](folder, packet, result)
        record['source_counters'] = source['counters']
        record['accepted_proposals'] = len(trace['proposals'])
        directories = report['controller_directories'](folder)
        log_dir = directories[-1] / 'artifact/logs'
        try:
            replay = report['verify_journal_replay'](folder, trace, packet, log_dir, pilot['validate_all_fact_citations'])
            record['partial_journal_replay'] = {'passed': True, 'receipt': replay}
        except ValueError as exc:
            record['partial_journal_replay'] = {'passed': False, 'error': str(exc)}
    else:
        assert not list(folder.glob('controller-*'))
        assert not (folder / 'trace.json').exists()
    cases.append(record)

original_files = sorted(p for p in ROOT.rglob('*') if p.is_file())
assert not any(p.is_symlink() for p in ROOT.rglob('*'))
entries = [(p, 'originals/' + p.relative_to(ROOT).as_posix()) for p in original_files]
entries.extend((Path(name), 'metadata/' + Path(name).name) for name in (
    '/tmp/unimatch-expert500-v9-launch-original.log',
    '/tmp/unimatch-expert500-v9-baseline-parent.log',
    '/tmp/unimatch-expert500-v9-baseline-pre-expert-validation.json',
    '/tmp/unimatch-expert500-v9-expert-parent.log',
    '/tmp/unimatch-expert500-v9-original-report-rejection.log',
    '/tmp/unimatch-expert500-close-v9.py',
))
DEST.mkdir(parents=True)
records = []
archive = DEST / 'originals.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
    for path, name in entries:
        data = path.read_bytes()
        fingerprint = hashlib.sha256(data).hexdigest()
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 0, 0o644
        tar.addfile(info, io.BytesIO(data))
        records.append({'archive_path': name, 'original_path': str(path), 'sha256': fingerprint, 'bytes': len(data)})
with tarfile.open(archive, 'r:gz') as tar:
    assert len(tar.getmembers()) == len(records)
    for record in records:
        member = tar.extractfile(record['archive_path'])
        assert member is not None
        assert hashlib.sha256(member.read()).hexdigest() == record['sha256']
        assert digest(Path(record['original_path'])) == record['sha256']

for name in ('experts-results.json', 'baseline-results.json'):
    (DEST / name).write_bytes((ROOT / name).read_bytes())
(DEST / 'report-rejection.log').write_bytes(Path('/tmp/unimatch-expert500-v9-original-report-rejection.log').read_bytes())
audit = {
    'schema_version': '1', 'recorded_at': datetime.now(UTC).isoformat(),
    'protocol_version': 'journal-v9', 'status': 'CLOSED_UNSCORED',
    'source': trial['harness_sha'], 'frozen_ref': trial['frozen_ref'],
    'trial_sha256': digest(ROOT / 'trial.json'), 'original_root': str(ROOT),
    'original_protocol_manifest_sha256': digest(protocol / 'manifest.json'),
    'frozen_scripts_verified': len(trial['scripts']), 'frozen_modules_verified': len(trial['modules']),
    'prior_baseline_checkpoint_records_verified': len(read(checkpoint)['records']),
    'baseline_completed': 10, 'baseline_provider_failures': 0,
    'model_calls': sum(c['model_calls'] for c in cases),
    'expert_source_actions': sum(c['recorded_source_actions'] for c in cases),
    'expert_with_accepted_journals': sum(c['accepted_turns'] > 0 for c in cases),
    'terminal_model_usage_refusals': len(cases),
    'original_parent_stopped': results['stopped'],
    'parent_defect': 'Model usage refusal did not set shared STOP; the queued seven selectors were attempted and refused.',
    'report_rejection': 'Controlled source ledger differs from recorded workflow executions; Vienna has zero source runs and no accepted primary receipt.',
    'seal_exists': False, 'labels_opened_by_this_audit': False, 'score': None,
    'outside_policy_collected': False, 'admission_gate_passed': False,
    'new_model_calls': 0, 'new_source_calls': 0, 'heldout_150_accessed': False,
    'cases': cases,
    'archive': {'path': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size,
                'original_trial_files': len(original_files), 'records': len(records),
                'uncompressed_bytes': sum(r['bytes'] for r in records), 'all_members_and_originals_reverified': True},
    'records': records,
}
(DEST / 'manifest.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({k: v for k, v in audit.items() if k not in ('records', 'cases')}, indent=2))
for case in cases:
    print(json.dumps({k:v for k,v in case.items() if k not in ('partial_journal_replay','model_refusal')}))
print('manifest_sha256', digest(DEST / 'manifest.json'))
